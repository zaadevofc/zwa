module.exports = {
    Connection: require('./modules/Connection'),
    Config: require('./modules/Config'),
    useDatabase: require('./use/Database'),
    useWatchFile: require('./use/WatchFile')
}