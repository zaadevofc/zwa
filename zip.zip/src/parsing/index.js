module.exports = {
    Calling: require('./Calling'),
    Message: require('./Message'),
    MsgDelete: require('./MsgDelete'),
    UpdateStatus: require('./UpdateStatus'),
}